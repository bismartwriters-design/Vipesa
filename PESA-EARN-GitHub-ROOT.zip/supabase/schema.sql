-- PESA EARN schema. Run in Supabase SQL Editor. Keep RLS enabled.
create extension if not exists pgcrypto;
create table if not exists public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 email text not null,
 full_name text,
 phone text,
 role text not null default 'member' check (role in ('member','admin')),
 status text not null default 'active' check (status in ('active','suspended')),
 created_at timestamptz not null default now()
);
create table if not exists public.ads (
 id uuid primary key default gen_random_uuid(), title text not null,
 description text, video_url text not null, thumbnail_url text,
 reward_kes numeric(12,2) not null check (reward_kes >= 0),
 duration_seconds integer not null default 15 check (duration_seconds > 0),
 active boolean not null default true, created_at timestamptz not null default now()
);
create table if not exists public.ad_views (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references public.profiles(id),
 ad_id uuid not null references public.ads(id), status text not null default 'started' check(status in ('started','pending_review','verified','rejected')),
 provider_reference text unique, started_at timestamptz not null default now(), completed_at timestamptz,
 unique(user_id,ad_id,started_at)
);
create table if not exists public.wallet_ledger (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references public.profiles(id),
 amount numeric(12,2) not null check(amount > 0), direction text not null check(direction in ('credit','debit')),
 status text not null default 'posted' check(status in ('posted','reversed')),
 description text, reference text unique, created_at timestamptz not null default now()
);
create table if not exists public.withdrawals (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references public.profiles(id),
 amount_kes numeric(12,2) not null check(amount_kes > 0), fee_kes numeric(12,2) not null default 0 check(fee_kes >= 0),
 phone text not null, status text not null default 'pending' check(status in ('pending','approved','processing','paid','failed','rejected')),
 mpesa_receipt text, provider_conversation_id text, failure_reason text,
 created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create or replace function public.is_admin() returns boolean language sql stable security definer set search_path=public as $$
 select exists(select 1 from public.profiles where id=auth.uid() and role='admin' and status='active');
$$;
create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$
begin
 insert into public.profiles(id,email,full_name,phone) values(new.id,new.email,coalesce(new.raw_user_meta_data->>'full_name',''),new.raw_user_meta_data->>'phone');
 return new;
end; $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();

-- Atomic withdrawal request: reserve pending/approved/processing withdrawals against available balance.
create or replace function public.request_withdrawal(p_amount_kes numeric,p_phone text) returns uuid
language plpgsql security definer set search_path=public as $$
declare v_balance numeric; v_reserved numeric; v_id uuid;
begin
 if auth.uid() is null then raise exception 'Please sign in'; end if;
 if p_amount_kes is null or p_amount_kes <= 0 then raise exception 'Enter a valid amount'; end if;
 if p_phone !~ '^254[0-9]{9}$' then raise exception 'Use a valid Kenyan M-Pesa number, e.g. 2547XXXXXXXX'; end if;
 perform 1 from public.profiles where id=auth.uid() and status='active' for update;
 if not found then raise exception 'Account is not active'; end if;
 select coalesce(sum(case when direction='credit' then amount else -amount end),0) into v_balance
 from public.wallet_ledger where user_id=auth.uid() and status='posted';
 select coalesce(sum(amount_kes),0) into v_reserved from public.withdrawals
 where user_id=auth.uid() and status in ('pending','approved','processing');
 if p_amount_kes > v_balance-v_reserved then raise exception 'Insufficient available balance'; end if;
 insert into public.withdrawals(user_id,amount_kes,phone) values(auth.uid(),p_amount_kes,p_phone) returning id into v_id;
 return v_id;
end; $$;
revoke all on function public.request_withdrawal(numeric,text) from public;
grant execute on function public.request_withdrawal(numeric,text) to authenticated;

alter table public.profiles enable row level security;
alter table public.ads enable row level security;
alter table public.ad_views enable row level security;
alter table public.wallet_ledger enable row level security;
alter table public.withdrawals enable row level security;
create policy "profile own or admin read" on public.profiles for select to authenticated using(id=auth.uid() or public.is_admin());
create policy "profile own update limited" on public.profiles for update to authenticated using(id=auth.uid()) with check(id=auth.uid() and role='member');
create policy "ads public active read" on public.ads for select to anon,authenticated using(active=true or public.is_admin());
create policy "admin manage ads" on public.ads for all to authenticated using(public.is_admin()) with check(public.is_admin());
create policy "own ad views read" on public.ad_views for select to authenticated using(user_id=auth.uid() or public.is_admin());
create policy "own ad views start" on public.ad_views for insert to authenticated with check(user_id=auth.uid() and status='started');
create policy "ledger own read" on public.wallet_ledger for select to authenticated using(user_id=auth.uid() or public.is_admin());
create policy "withdrawals own read" on public.withdrawals for select to authenticated using(user_id=auth.uid() or public.is_admin());
create policy "admin manage withdrawals" on public.withdrawals for update to authenticated using(public.is_admin()) with check(public.is_admin());
-- No client-side INSERT/UPDATE/DELETE policy for wallet_ledger. Only trusted server functions may credit/debit.

-- After the admin account has registered and confirmed its email, run this once:
-- update public.profiles set role='admin' where email='mcmbuish@gmail.com';
