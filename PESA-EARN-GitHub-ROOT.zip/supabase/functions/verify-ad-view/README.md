# Ad completion verification adapter

There is no universal video-ad completion API. Select a legitimate ad network/provider that supports server-side completion callbacks (S2S/postbacks). Implement its documented signature verification here before marking an `ad_views` row verified and inserting a matching `wallet_ledger` credit. Do not trust a browser timer, a JavaScript event, or a user-submitted screenshot as proof of a completed paid view.

Required checks:
- Verify provider signature/HMAC using a server-only secret.
- Confirm the provider campaign/ad maps to an active `ads` row.
- Enforce one reward per eligible user/view and provider event ID (unique reference).
- Check completion duration and fraud/rate limits.
- Insert the credit ledger entry with a unique provider reference in the same database transaction.
- Never accept an amount or user ID supplied only by the browser.
