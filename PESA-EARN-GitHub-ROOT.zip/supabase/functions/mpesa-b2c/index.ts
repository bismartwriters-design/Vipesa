// Supabase Edge Function: approved M-Pesa B2C payout.
// Configure all MPESA_* values as Supabase function secrets. Never expose them to the browser.
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { serve } from 'https://deno.land/std@0.224.0/http/server.ts';
const cors={ 'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'authorization, x-client-info, apikey, content-type' };
serve(async(req)=>{
 if(req.method==='OPTIONS')return new Response('ok',{headers:cors});
 try{
  const url=Deno.env.get('SUPABASE_URL')!, anon=Deno.env.get('SUPABASE_ANON_KEY')!, service=Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
  const auth=req.headers.get('Authorization')||'';const userClient=createClient(url,anon,{global:{headers:{Authorization:auth}}});
  const {data:{user},error:ue}=await userClient.auth.getUser();if(ue||!user)return new Response('Unauthorized',{status:401,headers:cors});
  const admin=createClient(url,service);const {data:profile}=await admin.from('profiles').select('role,status').eq('id',user.id).single();
  if(profile?.role!=='admin'||profile?.status!=='active')return new Response('Forbidden',{status:403,headers:cors});
  const {withdrawal_id}=await req.json();const {data:w,error:we}=await admin.from('withdrawals').select('*').eq('id',withdrawal_id).single();
  if(we||!w||w.status!=='approved')return new Response('Withdrawal must be approved first',{status:400,headers:cors});
  const key=Deno.env.get('MPESA_CONSUMER_KEY')!,secret=Deno.env.get('MPESA_CONSUMER_SECRET')!,base=Deno.env.get('MPESA_BASE_URL')!;
  const basic=btoa(`${key}:${secret}`);const tokenRes=await fetch(`${base}/oauth/v1/generate?grant_type=client_credentials`,{headers:{Authorization:`Basic ${basic}`}});const tokenData=await tokenRes.json();if(!tokenRes.ok)throw new Error('M-Pesa OAuth failed');
  const security=Deno.env.get('MPESA_SECURITY_CREDENTIAL')!;const shortcode=Deno.env.get('MPESA_SHORTCODE')!;
  const payload={InitiatorName:Deno.env.get('MPESA_INITIATOR_NAME'),SecurityCredential:security,CommandID:'BusinessPayment',Amount:Math.floor(Number(w.amount_kes)-Number(w.fee_kes||0)),PartyA:shortcode,PartyB:w.phone,Remarks:`PESA EARN withdrawal ${w.id}`,QueueTimeOutURL:Deno.env.get('MPESA_CALLBACK_URL'),ResultURL:Deno.env.get('MPESA_CALLBACK_URL'), occasion:`PESA EARN ${w.id}`};
  if(payload.Amount<=0)throw new Error('Net payout must be greater than zero');
  const sent=await fetch(`${base}/mpesa/b2c/v1/paymentrequest`,{method:'POST',headers:{Authorization:`Bearer ${tokenData.access_token}`,'Content-Type':'application/json'},body:JSON.stringify(payload)});const result=await sent.json();if(!sent.ok||result.ResponseCode!=='0')throw new Error(result.errorMessage||result.ResponseDescription||'M-Pesa request failed');
  await admin.from('withdrawals').update({status:'processing',provider_conversation_id:result.ConversationID,updated_at:new Date().toISOString()}).eq('id',w.id);
  return new Response(JSON.stringify({ok:true,message:'Payout submitted; wait for verified callback.'}),{headers:{...cors,'Content-Type':'application/json'}});
 }catch(e){return new Response(JSON.stringify({error:e.message||'Payout failed'}),{status:400,headers:{...cors,'Content-Type':'application/json'}})}
});
