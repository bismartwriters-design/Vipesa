// Daraja B2C result callback. Protect endpoint with a long random URL token and reconcile against stored ConversationID.
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { serve } from 'https://deno.land/std@0.224.0/http/server.ts';
serve(async(req)=>{
 try{
  const expected=Deno.env.get('MPESA_CALLBACK_TOKEN');
  if(!expected||new URL(req.url).searchParams.get('token')!==expected)return new Response('Not found',{status:404});
  const body=await req.json();const r=body?.Result;if(!r?.ConversationID)return new Response('Accepted',{status:200});
  const db=createClient(Deno.env.get('SUPABASE_URL')!,Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);
  const {data:w}=await db.from('withdrawals').select('*').eq('provider_conversation_id',r.ConversationID).eq('status','processing').maybeSingle();
  if(!w)return new Response('Accepted',{status:200});
  if(Number(r.ResultCode)===0&&r.TransactionID){
   const {error}=await db.from('withdrawals').update({status:'paid',mpesa_receipt:r.TransactionID,updated_at:new Date().toISOString()}).eq('id',w.id).eq('status','processing');
   if(!error)await db.from('wallet_ledger').insert({user_id:w.user_id,amount:w.amount_kes,direction:'debit',description:`M-Pesa payout ${r.TransactionID}`,reference:`withdrawal:${w.id}`,status:'posted'});
  }else{
   await db.from('withdrawals').update({status:'failed',failure_reason:String(r.ResultDesc||'M-Pesa payout failed').slice(0,400),updated_at:new Date().toISOString()}).eq('id',w.id).eq('status','processing');
  }
  return new Response('Accepted',{status:200});
 }catch(_){return new Response('Accepted',{status:200})}
});
